class Base62 {
  constructor() {
    this.chars = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //boleh dirubah2 // dishuffle "WAJIB!!! SAMA DENGAN class Base62 di script.js"
    this.base = this.chars.length;
  }

  encode(num) {
    let encoded = '';
    while (num > 0) {
      const remainder = num % this.base;
      num = Math.floor(num / this.base);
      encoded = this.chars[remainder] + encoded;
    }
    return encoded || '0';
  }

  decode(str) {
    let decoded = 0;
    for (let i = 0; i < str.length; i++) {
      const index = this.chars.indexOf(str[i]);
      if (index === -1) throw new Error("Invalid character in Base62 string");
      decoded = decoded * this.base + index;
    }
    return decoded;
  }
}

(async function() {
  try {
    const base62 = new Base62();
    const url = new URL(window.location.href);
    const queryParams = new URLSearchParams(url.search);

    const languageCode = queryParams.keys().next().value;
    const encodedProductId = queryParams.get(languageCode); 

    if (!languageCode || !encodedProductId) {
      console.error('Required query parameters not found.');
      return;
    }

    const subdomainMap = {
      it: 'it',
      ru: 'ru',
      id: 'id',
      fr: 'fr',
      tr: 'tr',
      pt: 'pt',
      th: 'th',
      vi: 'vi',
      de: 'de',
      es: 'es',
      ar: 'ar',
      cl: 'cl',
      ja: 'ja', 
      he: 'he',
      ko: 'ko',
      mx: 'mx',
      nl: 'nl',
      pl: 'pl',
      in: 'in',
      en: 'www'
    };

    const defaultSubdomain = 'm';
    let subdomain = subdomainMap[languageCode] || defaultSubdomain;

    const gotcha = '_dXTaSdi'; // GANTI NGGO TRACKINGMU
    let decodedProductId = null;

    if (encodedProductId) {
      decodedProductId = base62.decode(encodedProductId);
      const originalProductId = decodedProductId - 36;
      const redirectUrl = 'https://' + subdomain + '.aliexpress.com/item/' + originalProductId + '.html';

      if (/googlebot/i.test(navigator.userAgent)) {
        window.location.href = redirectUrl;
      } else {
        window.location.href = 'https://s.click.aliexpress.com/deep_link.htm?aff_short_key=' + gotcha + '&dl_target_url=' + encodeURIComponent(redirectUrl);
      }
    } else {
      console.error('No valid decodedProductId found.');
    }
  } catch (error) {
    console.error('An error occurred:', error);
  }
})();
