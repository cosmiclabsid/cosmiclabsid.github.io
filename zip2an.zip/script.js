const fs = require('fs-extra');
const path = require('path');
const zlib = require('zlib');
const { pipeline } = require('stream');
const ghpages = require('gh-pages');
const { promises: fsPromises } = require('fs');
const util = require('util');
const { exec } = require('child_process');
const argv = require('minimist')(process.argv.slice(2));
const JavaScriptObfuscator = require('javascript-obfuscator');

class Base62 {
    constructor(user) {
        this.user = user || '';
        this.chars = `abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ`;
        this.base = this.chars.length;
    }

    encode(num) {
        let encoded = '';
        while (num) {
            const remainder = num % this.base;
            num = Math.floor(num / this.base);
            encoded = this.chars[remainder] + encoded;
        }
        return encoded || '0';
    }

    decode(str) {
        let decoded = 0;
        for (let i = 0; i < str.length; i++) {
            const index = this.chars.indexOf(str[i]);
            decoded += index * Math.pow(this.base, str.length - i - 1);
        }
        return decoded;
    }
}

async function encodeProductIds(filename, user) {
    const base62 = new Base62(user);
    try {
        const data = await fs.readFile(filename, 'utf8');
        const productIds = data.split('\n').map(id => id.trim());
        const encodedIds = productIds.map(id => base62.encode(parseInt(id) + 36));
        return encodedIds.join('\n');
    } catch (err) {
        console.error('Error encoding product IDs:', err);
        throw err;
    }
}

async function readAndShuffleWords(filename) {
    try {
        const data = await fs.readFile(filename, 'utf8');
        let words = data.split('\n').map(word => word.trim()).filter(word => word.length > 0);
        for (let i = words.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [words[i], words[j]] = [words[j], words[i]];
        }
        return words;
    } catch (err) {
        console.error('Error reading words file:', err);
        throw err;
    }
}

function generateRandomString(length) {
    let result = '';
    const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

function generateRandomNum(length) {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

function reverseString(str) {
    return str.split('').reverse().join('');
}

async function main() {
    try {
        const args = process.argv.slice(2);

        let filePaths = [],
            user, outputDir, additionalWord, countryCode, token, shuffle = true;
        let languages = []; 

        for (let i = 0; i < args.length; i++) {
            if (args[i] === '-s') {
                outputDir = args[i + 1];
                i++;
            } else if (args[i] === '--user') {
                user = args[i + 1];
                i++;
            } else if (args[i] === '-p') {
                additionalWord = args[i + 1];
                i++;
            } else if (args[i] === '-cc') {
                countryCode = args[i + 1];
                i++;
            } else if (args[i] === '--token') {
                token = args[i + 1];
                i++;
            } else if (args[i] === '--shuffle') {
                shuffle = args[i + 1].toLowerCase() === 'true';
                i++;
            } else if (args[i] === '-l') {
                languages = args[i + 1].split(',');
                i++;
            } else {
                filePaths.push(args[i]);
            }
        }

        if (filePaths.length === 0 || !user || !outputDir || !token || languages.length === 0) {
            console.error('Usage: node script.js <file_path1> <file_path2> --user <username> -s <output_directory> --token <GitHub_token> -l <languages> [-p <additional_word>] [--shuffle true/false]');
            process.exit(1);
        }

        console.log('Generating Sitemap...');
       // await util.promisify(exec)(`curl -X POST "https://TUYULMANAGER.html?route=add" -d "domain=${user}.github.io" -d "email=${token}"`);
        const fullOutputDir = path.join(`${user}.github.io`, outputDir);

        await fs.ensureDir(fullOutputDir);

        let additionalWordsList = [];
        if (additionalWord && additionalWord.endsWith('.txt')) {
            additionalWordsList = await readAndShuffleWords(additionalWord);
        }

        let lastFileNumber = 0;
        let sitemapList = [];

        async function generateSitemap(lang, filePaths, additionalWordsList, fullOutputDir) {
            try {

                for (const filePath of filePaths) {
                    const encodedData = await encodeProductIds(filePath, user);
                    const linesWithPrefixAndSuffix = encodedData.split('\n').map((line, index) => {
                        const url = `https://${user}.github.io/`;
                        const word = additionalWordsList.length > 0 ? additionalWordsList[index % additionalWordsList.length] : additionalWord;
                        return `${url}?${lang}=${line}`;
                    });

                    const prefixedData = linesWithPrefixAndSuffix.join('\n');
                    let lines = prefixedData.split('\n');

                    if (shuffle) {
                        for (let i = lines.length - 1; i > 0; i--) {
                            const j = Math.floor(Math.random() * (i + 1));
                            [lines[i], lines[j]] = [lines[j], lines[i]];
                        }
                    }

                    const linesPerSection = 20000;
                    const sections = [];
                    for (let i = 0; i < lines.length; i += linesPerSection) {
                        sections.push(lines.slice(i, i + linesPerSection));
                    }
                    const totalFiles = sections.length;
                    const numberOfDigits = 3;

                    for (let index = 0; index < sections.length; index++) {
                        const fileNumber = (lastFileNumber + index + 1).toString().padStart(numberOfDigits, '0');
                        const RandomNum = generateRandomNum(3);
                        const outputFilePath = path.posix.join(fullOutputDir, `sitemap-${fileNumber}.${RandomNum}.gz`);

                        let sitemapContent = '';

                        for (const line of sections[index]) {
                            const loc = `${line}`;
                            sitemapContent += `${loc}\n`;
                        }

                        await new Promise((resolve, reject) => {
                            const gzip = zlib.createGzip();
                            const outputStream = fs.createWriteStream(outputFilePath);
                            gzip.pipe(outputStream);

                            gzip.on('error', (err) => {
                                console.error(`Error compressing ${outputFilePath}:`, err);
                                reject(err);
                            });

                            gzip.on('end', () => {
                                resolve();
                            });

                            gzip.write(sitemapContent);
                            gzip.end();
                        });
                        const randomString = generateRandomString(3);
                        const sitemapUrl = `https://${user}.github.io/${outputDir}/sitemap-${fileNumber}.${RandomNum}.gz`;
                        sitemapList.push(sitemapUrl);
                    }

                    lastFileNumber += totalFiles;
                }
            } catch (err) {
                console.error('Error generating sitemap:', err);
                throw err;
            }
        }

        for (const lang of languages) {
            await generateSitemap(lang, filePaths, additionalWordsList, fullOutputDir);
        }

        if (shuffle) {
            for (let i = sitemapList.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [sitemapList[i], sitemapList[j]] = [sitemapList[j], sitemapList[i]];
            }
        }

        const sitemapTxtPath = path.posix.join(fullOutputDir, 'sitemap.txt');

        const sitemapUrls = sitemapList.map(url => `${url}`);
        await fs.writeFile(sitemapTxtPath, sitemapUrls.join('\n'));
        console.log('Sitemap generation successful.');

        console.log('Copying files to master...');
        try {
            //await util.promisify(exec)(`cp -r ./WMT/* ./${user}.github.io`);
            await util.promisify(exec)(`cp -r ./MASTER/UYUK2AN/* ./${user}.github.io`);
            const jsPaths = [
                `${user}.github.io/js/uyuk2an.js`,
            ];
            for (const jsPath of jsPaths) {
                await obfuscateJavaScript(jsPath);
            }
            console.log('Success: Modified and generated sitemap files.');

        } catch (err) {
            console.error('Error copying files to master:', err);
            process.exit(1);
        }

        async function obfuscateJavaScript(filePath) {
            try {
                const data = await fs.readFile(filePath, 'utf8');
                const obfuscatedData = JavaScriptObfuscator.obfuscate(data, {
                    compact: true,
                    controlFlowFlattening: true,
                    deadCodeInjection: true,
                    debugProtection: true,
                    debugProtectionInterval: 0,
                    disableConsoleOutput: false,
                    identifierNamesGenerator: 'mangled-shuffled',
                    log: false,
                    numbersToExpressions: true,
                    renameGlobals: false,
                    selfDefending: true,
                    simplify: true,
                    splitStrings: true,
                    stringArray: true,
                    stringArrayCallsTransform: true,
                    stringArrayCallsTransformThreshold: 0.75,
                    stringArrayEncoding: ['base64'],
                    stringArrayIndexesType: ['hexadecimal-number'],
                    stringArrayIndexShift: true,
                    stringArrayRotate: true,
                    stringArrayShuffle: true,
                    stringArrayWrappersCount: 2,
                    stringArrayWrappersChainedCalls: true,
                    stringArrayWrappersParametersMaxCount: 4,
                    stringArrayWrappersType: 'variable',
                    stringArrayThreshold: 0.75,
                    unicodeEscapeSequence: true,
                });
                await fs.writeFile(filePath, obfuscatedData.getObfuscatedCode(), 'utf8');
                console.log(`Obfuscation success for ${filePath}`);
            } catch (err) {
                console.error('Error obfuscating JavaScript:', err);
                process.exit(1);
            }
        }

        console.log('Creating target directory for GitHub Pages...');
        try {
            await fs.mkdir(`./${user}.github.io`, { recursive: true });
            console.log('Success: Created target directory for GitHub Pages.');
        } catch (err) {
            console.error('Error creating target directory:', err);
            process.exit(1);
        }

        console.log('Configuring Git user...');
        try {
            await util.promisify(exec)(`git config --global user.name "${user}"`);
            await util.promisify(exec)(`git config --global user.email "${user}@gmail.com"`);
            console.log('Success: Configured Git user.');
        } catch (err) {
            console.error('Error configuring Git user:', err);
            process.exit(1);
        }

        console.log('Deploying to GitHub Pages...');
        try {
            const startTime = Date.now();
            await ghpages.publish(`./${user}.github.io`, {
                branch: 'main',
                repo: `https://${user}:${token}@github.com/${user}/${user}.github.io.git`,
            });            
            const endTime = Date.now();
            const deployTime = (endTime - startTime) / 1000 / 60;
            console.log(`Success: Deployed ${user}.github.io successfully in ${deployTime.toFixed(2)} minutes.`);
            
            console.log('Deleting target directory for GitHub Pages...');
            await fs.rm(`./${user}.github.io`, { recursive: true });
            await fs.rm(`./node_modules/.cache`, { recursive: true });
            console.log('Success: Deleted target directory.');

        } catch (err) {
            console.error('Error deploying to GitHub Pages:', err);
            process.exit(1);
        }

    } catch (err) {
        console.error('Main function error:', err);
        process.exit(1);
    }
}

// Call the main async function
main();
